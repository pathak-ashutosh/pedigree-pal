import { BytesLike } from "@ethersproject/bytes";
export declare function decode(textData: string): Uint8Array;
export declare function encode(data: BytesLike): string;
//# sourceMappingURL=base64.d.ts.map