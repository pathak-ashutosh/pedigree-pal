export const version = "properties/5.7.0";
//# sourceMappingURL=_version.js.map