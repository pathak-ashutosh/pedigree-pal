export const version = "strings/5.7.0";
