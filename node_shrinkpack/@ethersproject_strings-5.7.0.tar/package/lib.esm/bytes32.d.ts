import { BytesLike } from "@ethersproject/bytes";
export declare function formatBytes32String(text: string): string;
export declare function parseBytes32String(bytes: BytesLike): string;
//# sourceMappingURL=bytes32.d.ts.map