export declare function _nameprepTableA1(codepoint: number): boolean;
export declare function _nameprepTableB2(codepoint: number): Array<number>;
export declare function _nameprepTableC(codepoint: number): boolean;
export declare function nameprep(value: string): string;
//# sourceMappingURL=idna.d.ts.map