'use strict';

module.exports = require('./es2015');
