module.exports = require('./lib/command-exists');
