export declare function randomBytes(length: number): Uint8Array;
//# sourceMappingURL=browser-random.d.ts.map