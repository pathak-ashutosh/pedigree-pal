import { logger, Wordlist } from "./wordlist";
import { wordlists } from "./wordlists";
export { logger, Wordlist, wordlists };
//# sourceMappingURL=index.d.ts.map