"use strict";
import { langEn as en } from "./lang-en";
export const wordlists = {
    en: en
};
//# sourceMappingURL=wordlists.js.map