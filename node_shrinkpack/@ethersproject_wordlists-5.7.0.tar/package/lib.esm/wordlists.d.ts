import { Wordlist } from "./wordlist";
export declare const wordlists: {
    [locale: string]: Wordlist;
};
//# sourceMappingURL=wordlists.d.ts.map