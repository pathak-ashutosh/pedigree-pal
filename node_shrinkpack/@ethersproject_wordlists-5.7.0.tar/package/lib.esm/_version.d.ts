export declare const version = "wordlists/5.7.0";
//# sourceMappingURL=_version.d.ts.map