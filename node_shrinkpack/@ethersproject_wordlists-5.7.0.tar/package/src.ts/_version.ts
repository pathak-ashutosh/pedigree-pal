export const version = "wordlists/5.7.0";
