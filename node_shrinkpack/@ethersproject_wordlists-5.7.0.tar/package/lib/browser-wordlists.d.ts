import { Wordlist } from "./wordlist";
export declare const wordlists: {
    [locale: string]: Wordlist;
};
//# sourceMappingURL=browser-wordlists.d.ts.map