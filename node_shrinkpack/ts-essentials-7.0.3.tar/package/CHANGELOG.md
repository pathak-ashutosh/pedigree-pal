# ts-essentials

## 7.0.3
### Patch Changes

- f917f9b: Refactor Opaque, now `__TYPE__` is not accessible at all
