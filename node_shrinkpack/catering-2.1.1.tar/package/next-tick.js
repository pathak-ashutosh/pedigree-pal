module.exports = process.nextTick.bind(process)
