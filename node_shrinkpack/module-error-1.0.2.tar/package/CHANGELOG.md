# Changelog

## [1.0.2] - 2022-02-19

### Fixed

- Align LICENSE format with standardized SPDX ([`915c436`](https://github.com/vweevers/module-error/commit/915c436)).

## [1.0.1] - 2021-10-24

### Fixed

- Add types ([`027e1ea`](https://github.com/vweevers/module-error/commit/027e1ea))

## [1.0.0] - 2021-10-22

:seedling: Initial release.

[1.0.2]: https://github.com/vweevers/module-error/releases/tag/v1.0.2

[1.0.1]: https://github.com/vweevers/module-error/releases/tag/v1.0.1

[1.0.0]: https://github.com/vweevers/module-error/releases/tag/v1.0.0
