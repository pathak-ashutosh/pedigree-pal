exports.Level = require('classic-level').ClassicLevel
