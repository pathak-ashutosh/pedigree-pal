exports.Level = require('browser-level').BrowserLevel
