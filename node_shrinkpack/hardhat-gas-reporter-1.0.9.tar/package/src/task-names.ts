export const TASK_GAS_REPORTER_MERGE_REPORTS = "gas-reporter:merge-reports";
export const TASK_GAS_REPORTER_MERGE = "gas-reporter:merge";
