# `@nomicfoundation/solidity-analyzer-freebsd-x64`

This is the **x86_64-unknown-freebsd** binary for `@nomicfoundation/solidity-analyzer`
