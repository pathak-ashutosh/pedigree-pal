# `@nomicfoundation/solidity-analyzer-darwin-arm64`

This is the **aarch64-apple-darwin** binary for `@nomicfoundation/solidity-analyzer`
