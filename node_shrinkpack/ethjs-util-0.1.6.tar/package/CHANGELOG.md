# 0.1.3 -- less dependencies

1. Less dependencies
2. Smaller build size
3. More docs

# 0.1.2 -- config fixes

1. webpack config updates
2. build config updates

# 0.1.1 -- less dependencies

1. Less dependencies, same functionality
2. More tests
3. More docs

# 0.0.5 -- more config

1. Module configuration for es5, webpack and dist builds

# 0.0.4 -- remove unused deps

1. Removed one unused dep

# 0.0.3 -- added `some` property to arrayContainsArray

1. added `some` property to arrayContainsArray, allows some array in another

# 0.0.2 -- added isHexString and getKeys

1. added `isHexString` method
2. added `getKeys` method util

# 0.0.1 -- ethjs-util

1. Basic testing
2. Basic docs
3. License
4. linting
5. basic exports
