export const version = "wallet/5.7.0";
