export enum SupportedAlgorithm { sha256 = "sha256", sha512 = "sha512" };

