export const version = "sha2/5.7.0";
//# sourceMappingURL=_version.js.map