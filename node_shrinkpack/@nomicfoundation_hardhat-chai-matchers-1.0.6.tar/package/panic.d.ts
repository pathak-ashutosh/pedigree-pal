export { PANIC_CODES } from "./internal/reverted/panic";
//# sourceMappingURL=panic.d.ts.map