"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.anyValue = exports.anyUint = void 0;
var withArgs_1 = require("./internal/withArgs");
Object.defineProperty(exports, "anyUint", { enumerable: true, get: function () { return withArgs_1.anyUint; } });
Object.defineProperty(exports, "anyValue", { enumerable: true, get: function () { return withArgs_1.anyValue; } });
//# sourceMappingURL=withArgs.js.map