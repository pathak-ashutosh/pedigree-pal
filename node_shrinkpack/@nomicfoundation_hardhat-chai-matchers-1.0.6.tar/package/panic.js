"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PANIC_CODES = void 0;
// re-export here so users can import from "@nomicfoundation/hardhat-chai-matchers/panic"
var panic_1 = require("./internal/reverted/panic");
Object.defineProperty(exports, "PANIC_CODES", { enumerable: true, get: function () { return panic_1.PANIC_CODES; } });
//# sourceMappingURL=panic.js.map