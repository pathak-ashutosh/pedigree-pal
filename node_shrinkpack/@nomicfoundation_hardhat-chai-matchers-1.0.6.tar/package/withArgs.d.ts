export { anyUint, anyValue } from "./internal/withArgs";
//# sourceMappingURL=withArgs.d.ts.map