/// <reference types="chai" />
export declare function supportRevertedWithoutReason(Assertion: Chai.AssertionStatic): void;
//# sourceMappingURL=revertedWithoutReason.d.ts.map