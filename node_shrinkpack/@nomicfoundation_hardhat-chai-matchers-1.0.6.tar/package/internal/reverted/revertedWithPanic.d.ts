/// <reference types="chai" />
export declare function supportRevertedWithPanic(Assertion: Chai.AssertionStatic): void;
//# sourceMappingURL=revertedWithPanic.d.ts.map