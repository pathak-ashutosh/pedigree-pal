/// <reference types="chai" />
export declare function supportReverted(Assertion: Chai.AssertionStatic): void;
//# sourceMappingURL=reverted.d.ts.map