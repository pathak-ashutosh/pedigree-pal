/// <reference types="chai" />
export declare function supportRevertedWith(Assertion: Chai.AssertionStatic): void;
//# sourceMappingURL=revertedWith.d.ts.map