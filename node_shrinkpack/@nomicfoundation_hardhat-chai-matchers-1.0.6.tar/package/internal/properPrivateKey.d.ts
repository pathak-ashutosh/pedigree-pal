/// <reference types="chai" />
export declare function supportProperPrivateKey(Assertion: Chai.AssertionStatic): void;
//# sourceMappingURL=properPrivateKey.d.ts.map