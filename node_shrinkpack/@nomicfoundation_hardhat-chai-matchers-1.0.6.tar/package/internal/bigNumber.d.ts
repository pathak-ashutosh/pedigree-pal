/// <reference types="chai" />
export declare function supportBigNumber(Assertion: Chai.AssertionStatic, utils: Chai.ChaiUtils): void;
//# sourceMappingURL=bigNumber.d.ts.map