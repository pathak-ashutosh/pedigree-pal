export declare function hardhatWaffleIncompatibilityCheck(): void;
//# sourceMappingURL=hardhatWaffleIncompatibilityCheck.d.ts.map