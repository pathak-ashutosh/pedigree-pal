import { CustomError } from "hardhat/common";
export declare class HardhatChaiMatchersDecodingError extends CustomError {
    constructor(encodedData: string, type: string, parent: Error);
}
//# sourceMappingURL=errors.d.ts.map