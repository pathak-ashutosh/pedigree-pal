/// <reference types="chai" />
export declare function supportProperAddress(Assertion: Chai.AssertionStatic): void;
//# sourceMappingURL=properAddress.d.ts.map