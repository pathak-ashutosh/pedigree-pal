/// <reference types="chai" />
export declare function hardhatChaiMatchers(chai: Chai.ChaiStatic, utils: Chai.ChaiUtils): void;
//# sourceMappingURL=hardhatChaiMatchers.d.ts.map