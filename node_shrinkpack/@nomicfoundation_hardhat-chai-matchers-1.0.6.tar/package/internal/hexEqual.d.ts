/// <reference types="chai" />
export declare function supportHexEqual(Assertion: Chai.AssertionStatic): void;
//# sourceMappingURL=hexEqual.d.ts.map