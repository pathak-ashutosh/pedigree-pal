/// <reference types="chai" />
export declare function supportProperHex(Assertion: Chai.AssertionStatic): void;
//# sourceMappingURL=properHex.d.ts.map