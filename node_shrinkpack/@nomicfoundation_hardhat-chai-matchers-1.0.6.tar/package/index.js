"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("@nomiclabs/hardhat-ethers");
require("./types");
const hardhatWaffleIncompatibilityCheck_1 = require("./internal/hardhatWaffleIncompatibilityCheck");
require("./internal/add-chai-matchers");
(0, hardhatWaffleIncompatibilityCheck_1.hardhatWaffleIncompatibilityCheck)();
//# sourceMappingURL=index.js.map