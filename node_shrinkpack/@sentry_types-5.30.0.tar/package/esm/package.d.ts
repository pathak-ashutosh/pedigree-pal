/** JSDoc */
export interface Package {
    name: string;
    version: string;
}
//# sourceMappingURL=package.d.ts.map