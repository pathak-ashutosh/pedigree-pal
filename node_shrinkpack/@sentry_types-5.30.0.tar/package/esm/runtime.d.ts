/** Runtime Context. */
export interface Runtime {
    name?: string;
    version?: string;
}
//# sourceMappingURL=runtime.d.ts.map