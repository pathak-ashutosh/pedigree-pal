/**
 * Just an Error object with arbitrary attributes attached to it.
 */
export interface ExtendedError extends Error {
    [key: string]: any;
}
//# sourceMappingURL=error.d.ts.map