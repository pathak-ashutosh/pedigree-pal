/**
 * Consumes the promise and logs the error when it rejects.
 * @param promise A promise to forget.
 */
export declare function forget(promise: PromiseLike<any>): void;
//# sourceMappingURL=async.d.ts.map