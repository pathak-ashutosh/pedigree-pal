export declare const setPrototypeOf: (o: any, proto: object | null) => any;
//# sourceMappingURL=polyfill.d.ts.map