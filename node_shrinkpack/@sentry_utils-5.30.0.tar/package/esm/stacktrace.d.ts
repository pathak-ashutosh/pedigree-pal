/**
 * Safely extract function name from itself
 */
export declare function getFunctionName(fn: unknown): string;
//# sourceMappingURL=stacktrace.d.ts.map