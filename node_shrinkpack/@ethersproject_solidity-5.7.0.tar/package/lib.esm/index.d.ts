export declare function pack(types: ReadonlyArray<string>, values: ReadonlyArray<any>): string;
export declare function keccak256(types: ReadonlyArray<string>, values: ReadonlyArray<any>): string;
export declare function sha256(types: ReadonlyArray<string>, values: ReadonlyArray<any>): string;
//# sourceMappingURL=index.d.ts.map