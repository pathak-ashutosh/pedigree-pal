export const version = "solidity/5.7.0";
