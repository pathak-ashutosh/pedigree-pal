# 0.1.5 -- update bn formatting

1. Update bn formatting

# 0.1.3 -- config fixes

1. webpack config updates
2. build config updates

# 0.1.2 -- removed BigNumber's, replaced with all BN.js

1. new approach with BN.js and absolute precision
2. more coverage
3. more docs

# 0.0.2 -- ethjs-unit

1. More test coverage
2. Config
3. More docs

# 0.0.1 -- ethjs-unit

1. Basic testing
2. Basic docs
3. License
4. Linting
5. Basic exports
