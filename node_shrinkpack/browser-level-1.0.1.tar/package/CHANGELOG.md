# Changelog

## [1.0.1] - 2022-03-06

### Fixed

- Fix TypeScript type declarations ([`d5db420`](https://github.com/Level/browser-level/commit/d5db420)) (Vincent Weevers)

## [1.0.0] - 2022-03-05

_:seedling: Initial release. If you are upgrading from `level-js`, please see [UPGRADING.md](UPGRADING.md)._

[1.0.1]: https://github.com/Level/browser-level/releases/tag/v1.0.1

[1.0.0]: https://github.com/Level/browser-level/releases/tag/v1.0.0
