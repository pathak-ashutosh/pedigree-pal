/**
 * Configures global error listeners
 */
export declare function registerErrorInstrumentation(): void;
//# sourceMappingURL=errors.d.ts.map