import { Metric } from '../types';
export declare const initMetric: (name: "CLS" | "FCP" | "FID" | "LCP" | "TTFB", value?: number) => Metric;
//# sourceMappingURL=initMetric.d.ts.map