declare type HiddenType = {
    readonly timeStamp: number;
};
export declare const getFirstHidden: () => HiddenType;
export {};
//# sourceMappingURL=getFirstHidden.d.ts.map