export declare const whenInput: () => Promise<Event>;
//# sourceMappingURL=whenInput.d.ts.map