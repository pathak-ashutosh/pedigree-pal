import { ReportHandler } from './types';
export declare const getLCP: (onReport: ReportHandler, reportAllChanges?: boolean) => void;
//# sourceMappingURL=getLCP.d.ts.map