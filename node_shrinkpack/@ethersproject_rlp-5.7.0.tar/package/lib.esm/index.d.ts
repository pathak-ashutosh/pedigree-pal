import { BytesLike } from "@ethersproject/bytes";
export declare function encode(object: any): string;
export declare function decode(data: BytesLike): any;
//# sourceMappingURL=index.d.ts.map