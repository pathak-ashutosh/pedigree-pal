# Installation
> `npm install --save @types/chai-as-promised`

# Summary
This package contains type definitions for chai-as-promised (https://github.com/domenic/chai-as-promised/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/chai-as-promised.

### Additional Details
 * Last updated: Thu, 10 Feb 2022 18:01:30 GMT
 * Dependencies: [@types/chai](https://npmjs.com/package/@types/chai)
 * Global values: none

# Credits
These definitions were written by [jt000](https://github.com/jt000), [Yuki Kokubun](https://github.com/Kuniwak), [Leonard Thieu](https://github.com/leonard-thieu), [Mike Lazer-Walker](https://github.com/lazerwalker), [Matt Bishop](https://github.com/mattbishop), and [William Orr](https://github.com/worr).
