/**
 * @deprecated
 */
import { Reporter } from './Reporter';
/**
 * @since 1.0.0
 * @deprecated
 */
export declare const ThrowReporter: Reporter<void>;
