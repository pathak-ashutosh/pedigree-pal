export const version = "abstract-provider/5.7.0";
//# sourceMappingURL=_version.js.map