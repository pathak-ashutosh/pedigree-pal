export default function combinations<T>(
  array: Array<T>,
  r: number
): IterableIterator<Array<T>>;
