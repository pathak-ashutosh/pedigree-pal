export default function permutations<T>(
  array: Array<T>,
  r: number
): IterableIterator<Array<T>>;
