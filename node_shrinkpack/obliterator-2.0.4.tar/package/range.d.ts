export default function range(end: number): IterableIterator<number>;
export default function range(
  start: number,
  end: number
): IterableIterator<number>;
export default function range(
  start: number,
  end: number,
  step: number
): IterableIterator<number>;
