export default function consume<T>(iterator: Iterator<T>, steps?: number): void;
