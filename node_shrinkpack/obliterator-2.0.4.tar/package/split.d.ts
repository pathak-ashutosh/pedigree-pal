export default function split(
  pattern: RegExp,
  string: string
): IterableIterator<string>;
