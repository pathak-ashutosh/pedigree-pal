exports.ARRAY_BUFFER_SUPPORT = typeof ArrayBuffer !== 'undefined';
exports.SYMBOL_SUPPORT = typeof Symbol !== 'undefined';
