export default function match(
  pattern: RegExp,
  string: string
): IterableIterator<string>;
