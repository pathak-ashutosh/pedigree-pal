export default function iter<T>(target: unknown): Iterator<T>;
