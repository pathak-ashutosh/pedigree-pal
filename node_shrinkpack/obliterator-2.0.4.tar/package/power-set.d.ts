export default function powerSet<T>(
  array: Array<T>
): IterableIterator<Array<T>>;
