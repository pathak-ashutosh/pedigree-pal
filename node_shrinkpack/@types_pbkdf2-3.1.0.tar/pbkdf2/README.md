# Installation
> `npm install --save @types/pbkdf2`

# Summary
This package contains type definitions for pbkdf2 (https://github.com/crypto-browserify/pbkdf2).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/pbkdf2.

### Additional Details
 * Last updated: Sat, 18 Jul 2020 15:47:21 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Timon Engelke](https://github.com/timonegk).
