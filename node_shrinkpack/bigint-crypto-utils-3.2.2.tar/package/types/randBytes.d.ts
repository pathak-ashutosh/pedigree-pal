/// <reference types="node" />
export declare function randBytes(byteLength: number, forceLength?: boolean): Promise<Uint8Array | Buffer>;
export declare function randBytesSync(byteLength: number, forceLength?: boolean): Uint8Array | Buffer;
//# sourceMappingURL=randBytes.d.ts.map