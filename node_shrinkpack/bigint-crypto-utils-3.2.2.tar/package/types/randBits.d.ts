/// <reference types="node" />
export declare function randBits(bitLength: number, forceLength?: boolean): Promise<Uint8Array | Buffer>;
export declare function randBitsSync(bitLength: number, forceLength?: boolean): Uint8Array | Buffer;
//# sourceMappingURL=randBits.d.ts.map