export declare function randBetween(max: bigint, min?: bigint): bigint;
//# sourceMappingURL=randBetween.d.ts.map