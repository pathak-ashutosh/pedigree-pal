export declare function prime(bitLength: number, iterations?: number): Promise<bigint>;
export declare function primeSync(bitLength: number, iterations?: number): bigint;
//# sourceMappingURL=prime.d.ts.map