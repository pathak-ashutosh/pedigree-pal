export declare function isProbablyPrime(w: number | bigint, iterations?: number, disableWorkers?: boolean): Promise<boolean>;
export declare function _isProbablyPrime(w: bigint, iterations: number): boolean;
export declare function _isProbablyPrimeWorkerUrl(): string;
//# sourceMappingURL=isProbablyPrime.d.ts.map