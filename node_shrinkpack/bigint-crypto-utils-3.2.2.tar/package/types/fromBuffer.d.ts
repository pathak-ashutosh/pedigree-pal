/// <reference types="node" />
export declare function fromBuffer(buf: Uint8Array | Buffer): bigint;
//# sourceMappingURL=fromBuffer.d.ts.map