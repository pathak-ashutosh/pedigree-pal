export declare const version = "bignumber/5.7.0";
//# sourceMappingURL=_version.d.ts.map