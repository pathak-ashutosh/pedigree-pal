global.should = require('./').should();
