global.assert = require('./').assert;
