export const version = "signing-key/5.7.0";
//# sourceMappingURL=_version.js.map