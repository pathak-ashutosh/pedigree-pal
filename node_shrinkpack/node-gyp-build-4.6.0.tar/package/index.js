if (typeof process.addon === 'function') { // if the platform supports native resolving prefer that
  module.exports = process.addon.bind(process)
} else { // else use the runtime version here
  module.exports = require('./node-gyp-build.js')
}
