import { Parser } from './';

declare const parser: {
    parsers: {
        typescript: Parser;
    };
};
export = parser;
