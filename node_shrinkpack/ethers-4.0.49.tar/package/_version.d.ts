export declare const version = "4.0.49";
