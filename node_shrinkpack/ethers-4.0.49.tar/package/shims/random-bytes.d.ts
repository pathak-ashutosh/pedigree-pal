export declare function randomBytes(length: number): Uint8Array;
