"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require('setimmediate');
exports.platform = "browser";
