import { Wordlist } from '../utils/wordlist';
declare const en: Wordlist;
export { en };
