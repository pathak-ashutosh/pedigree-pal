export declare const platform = "browser";
