"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var lang_en_1 = require("../wordlists/lang-en");
var en = lang_en_1.langEn;
exports.en = en;
