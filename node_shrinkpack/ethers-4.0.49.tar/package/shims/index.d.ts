/**
 *  This file is not imported anywhere, but is used to trigger TypeScript
 *  compilation of the various shims for the browser.
 */
export {};
