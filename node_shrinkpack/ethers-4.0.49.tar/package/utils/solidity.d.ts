export declare function pack(types: Array<string>, values: Array<any>): string;
export declare function keccak256(types: Array<string>, values: Array<any>): string;
export declare function sha256(types: Array<string>, values: Array<any>): string;
