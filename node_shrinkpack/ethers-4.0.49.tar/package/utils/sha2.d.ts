import { Arrayish } from './bytes';
export declare function ripemd160(data: Arrayish): string;
export declare function sha256(data: Arrayish): string;
export declare function sha512(data: Arrayish): string;
