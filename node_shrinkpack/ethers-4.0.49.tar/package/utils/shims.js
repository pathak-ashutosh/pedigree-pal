"use strict";
/* no shims for node */
Object.defineProperty(exports, "__esModule", { value: true });
exports.platform = 'node';
