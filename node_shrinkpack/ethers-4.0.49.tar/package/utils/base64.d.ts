import { Arrayish } from './bytes';
export declare function decode(textData: string): Uint8Array;
export declare function encode(data: Arrayish): string;
