import { Arrayish } from './bytes';
export declare function namehash(name: string): string;
export declare function id(text: string): string;
export declare function hashMessage(message: Arrayish | string): string;
