import { Arrayish } from './bytes';
export declare function encode(object: any): string;
export declare function decode(data: Arrayish): any;
