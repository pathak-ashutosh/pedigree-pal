export declare function isCrowdsaleWallet(json: string): boolean;
export declare function isSecretStorageWallet(json: string): boolean;
export declare function getJsonWalletAddress(json: string): string;
