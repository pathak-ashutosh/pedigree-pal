export declare const platform = "node";
