require('../').register({
  transpileOnly: true,
});
