// For require('solidity-coverage/utils');
const utils = require('./plugins/resources/plugin.utils');

module.exports = utils;
