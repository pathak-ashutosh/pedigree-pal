// For require('solidity-coverage/api');
const api = require('./lib/api');

module.exports = api;
