module.exports = require('./lib/api')(require('node-gyp-build')(__dirname))
