export const version = "basex/5.7.0";
//# sourceMappingURL=_version.js.map