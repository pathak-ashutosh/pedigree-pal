declare function textEndec (): {
  textEncoder: TextEncoder
  textDecoder: TextDecoder
}

export = textEndec
