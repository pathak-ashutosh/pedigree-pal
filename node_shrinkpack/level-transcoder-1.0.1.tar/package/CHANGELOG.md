# Changelog

## [1.0.1] - 2021-11-26

### Fixed

- Remove `codecs` from supported interfaces in `README` ([`3b6b003`](https://github.com/Level/transcoder/commit/3b6b003))

## [1.0.0] - 2021-11-07

_:seedling: Initial release._

[1.0.1]: https://github.com/Level/transcoder/releases/tag/v1.0.1

[1.0.0]: https://github.com/Level/transcoder/releases/tag/v1.0.0
