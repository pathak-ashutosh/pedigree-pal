"use strict";

export function connect() { }
