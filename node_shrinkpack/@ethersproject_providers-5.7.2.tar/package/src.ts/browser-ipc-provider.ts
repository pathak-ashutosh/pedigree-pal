"use strict";

const IpcProvider: any = null;

export {
    IpcProvider
};
