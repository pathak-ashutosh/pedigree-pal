export const version = "providers/5.7.2";
//# sourceMappingURL=_version.js.map