declare let WS: any;
export { WS as WebSocket };
//# sourceMappingURL=ws.d.ts.map