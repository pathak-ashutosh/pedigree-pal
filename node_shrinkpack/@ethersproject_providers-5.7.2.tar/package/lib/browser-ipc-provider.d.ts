declare const IpcProvider: any;
export { IpcProvider };
//# sourceMappingURL=browser-ipc-provider.d.ts.map