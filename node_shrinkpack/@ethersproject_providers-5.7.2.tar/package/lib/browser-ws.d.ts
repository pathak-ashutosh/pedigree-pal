declare let WS: any;
export { WS as WebSocket };
//# sourceMappingURL=browser-ws.d.ts.map