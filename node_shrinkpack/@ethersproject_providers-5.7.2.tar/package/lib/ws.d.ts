import WebSocket from "ws";
export { WebSocket };
//# sourceMappingURL=ws.d.ts.map