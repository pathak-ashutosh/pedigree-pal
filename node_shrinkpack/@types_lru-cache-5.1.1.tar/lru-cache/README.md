# Installation
> `npm install --save @types/lru-cache`

# Summary
This package contains type definitions for lru-cache (https://github.com/isaacs/node-lru-cache).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lru-cache.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 22:02:58 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Bart van der Schoor](https://github.com/Bartvds), and [BendingBender](https://github.com/BendingBender).
