export default function indicator (i: number): string
