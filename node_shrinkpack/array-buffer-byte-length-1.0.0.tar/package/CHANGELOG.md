# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v1.0.0 - 2023-02-28

### Commits

- Initial implementation, tests, readme [`2db6cad`](https://github.com/inspect-js/array-buffer-byte-length/commit/2db6cad79270ab1966f5ea80160abbcd4534c91d)
- Initial commit [`b2a0c9c`](https://github.com/inspect-js/array-buffer-byte-length/commit/b2a0c9c2246514b7999d331aad868c4f32326db7)
- npm init [`376acdb`](https://github.com/inspect-js/array-buffer-byte-length/commit/376acdbd4435cb1d4c31d107cacb3b86f2363aee)
- Only apps should have lockfiles [`70cf325`](https://github.com/inspect-js/array-buffer-byte-length/commit/70cf32526fc727d0d16a12d85a4bddea70075e31)
