import { BytesLike } from "@ethersproject/bytes";
export declare function keccak256(data: BytesLike): string;
//# sourceMappingURL=index.d.ts.map