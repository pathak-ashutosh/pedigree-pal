# browser demo

How to build `browser/mcl.js`.
```
cd browser
npm install webpack webpack-cli --save-dev
npx webpack
python3 -m http.server
```

