# `@nomicfoundation/solidity-analyzer-linux-arm64-gnu`

This is the **aarch64-unknown-linux-gnu** binary for `@nomicfoundation/solidity-analyzer`
