export declare type Headers = {
    readonly [name: string]: string | string[];
};
