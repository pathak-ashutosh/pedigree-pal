import type { GetUrlResponse, Options } from "./types";
export { GetUrlResponse, Options };
export declare function getUrl(href: string, options?: Options): Promise<GetUrlResponse>;
//# sourceMappingURL=geturl.d.ts.map