export declare const version = "web/5.7.1";
//# sourceMappingURL=_version.d.ts.map