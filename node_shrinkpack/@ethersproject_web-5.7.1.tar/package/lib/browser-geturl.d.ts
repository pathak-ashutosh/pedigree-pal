import type { GetUrlResponse, Options } from "./types";
export { GetUrlResponse, Options };
export declare function getUrl(href: string, options?: Options): Promise<GetUrlResponse>;
//# sourceMappingURL=browser-geturl.d.ts.map