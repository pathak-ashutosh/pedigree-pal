/**
 * Converts milliseconds into seconds
 */
export function millis(n: number): number {
  return Math.floor(n / 1000);
}
