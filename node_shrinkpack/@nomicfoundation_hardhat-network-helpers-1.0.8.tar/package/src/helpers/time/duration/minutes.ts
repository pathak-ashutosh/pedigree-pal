/**
 * Converts minutes into seconds
 */
export function minutes(n: number): number {
  return n * 60;
}
