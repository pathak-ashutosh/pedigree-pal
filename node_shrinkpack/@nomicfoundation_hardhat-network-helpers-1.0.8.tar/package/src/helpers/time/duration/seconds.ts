/**
 * Converts seconds into seconds (noop)
 */
export function seconds(n: number): number {
  return n;
}
