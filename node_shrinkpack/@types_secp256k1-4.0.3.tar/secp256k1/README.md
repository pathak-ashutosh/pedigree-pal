# Installation
> `npm install --save @types/secp256k1`

# Summary
This package contains type definitions for secp256k1 (https://github.com/cryptocoinjs/secp256k1-node).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/secp256k1.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 16:34:26 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Anler](https://github.com/anler).
