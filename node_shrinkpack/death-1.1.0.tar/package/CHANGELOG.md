1.1.0 / 2017-01-18
------------------
- ability to remove listeners

1.0.0 / 2015-03-17
------------------
- removed `homepage` field in `package.json`
- small formatting changes

0.1.0 / 2013-02-18
------------------
* Fixed bugs due to setting of `uncaughtException`. Closes #1
* Changed default of `uncaughtException` from `true` to `false`.
* Removed aliases for `uncaughtException`.
* Fixed bug that when a key is set to false, it's still caught.
* Passed signal to callback.


0.0.1 / 2012-12-01
------------------
* Initial release.
