'use strict';

module.exports = require('./lib/errors.js');
