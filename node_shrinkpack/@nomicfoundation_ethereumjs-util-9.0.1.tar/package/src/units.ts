/** Easy conversion from Gwei to wei */
export const GWEI_TO_WEI = BigInt(1000000000)
