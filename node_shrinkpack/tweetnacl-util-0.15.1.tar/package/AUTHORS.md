List of authors
===============

    Alphabetical order by first name.
    Format: Name (GitHub username or URL)

* AndSDev (@AndSDev)
* Dmitry Chestnykh (@dchest)
