export declare type Require<T, K extends keyof T> = T & Required<Pick<T, K>>;
//# sourceMappingURL=types.d.ts.map