export declare const Case: {
    snake: (field: string) => string;
    constant: (field: string) => string;
    pascal: (field: string) => string;
    camel: (field: string) => string;
    header: (field: string) => string;
    eth2: (field: string) => string;
};
//# sourceMappingURL=strings.d.ts.map