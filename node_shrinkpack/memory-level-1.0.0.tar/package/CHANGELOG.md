# Changelog

## [1.0.0] - 2022-01-30

_:seedling: Initial release. If you are upgrading from `memdown`: please see [`UPGRADING.md`](./UPGRADING.md)._

[1.0.0]: https://github.com/Level/memory-level/releases/tag/v1.0.0
