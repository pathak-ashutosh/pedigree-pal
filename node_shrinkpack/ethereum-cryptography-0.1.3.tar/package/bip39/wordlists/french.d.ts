export declare const wordlist: string[];
//# sourceMappingURL=french.d.ts.map