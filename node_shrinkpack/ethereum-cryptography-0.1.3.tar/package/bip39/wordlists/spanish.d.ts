export declare const wordlist: string[];
//# sourceMappingURL=spanish.d.ts.map