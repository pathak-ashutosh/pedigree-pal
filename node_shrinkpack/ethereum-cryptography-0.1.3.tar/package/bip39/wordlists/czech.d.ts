export declare const wordlist: string[];
//# sourceMappingURL=czech.d.ts.map