export declare const wordlist: string[];
//# sourceMappingURL=english.d.ts.map