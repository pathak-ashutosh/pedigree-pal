import * as hdkeyPure from "./pure/hdkey";
export declare const HDKey: typeof hdkeyPure.HDKeyT;
//# sourceMappingURL=hdkey.d.ts.map