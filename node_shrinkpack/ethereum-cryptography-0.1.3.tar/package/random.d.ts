/// <reference types="node" />
export declare function getRandomBytes(bytes: number): Promise<Buffer>;
export declare function getRandomBytesSync(bytes: number): Buffer;
//# sourceMappingURL=random.d.ts.map