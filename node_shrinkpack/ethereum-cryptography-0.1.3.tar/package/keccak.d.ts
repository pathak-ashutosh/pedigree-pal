/// <reference types="node" />
export declare const keccak224: (msg: Buffer) => Buffer;
export declare const keccak256: (msg: Buffer) => Buffer;
export declare const keccak384: (msg: Buffer) => Buffer;
export declare const keccak512: (msg: Buffer) => Buffer;
//# sourceMappingURL=keccak.d.ts.map