"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var crypto_1 = require("crypto");
exports.createHash = crypto_1.createHash;
exports.createHmac = crypto_1.createHmac;
exports.randomBytes = crypto_1.randomBytes;
//# sourceMappingURL=hdkey-crypto.js.map