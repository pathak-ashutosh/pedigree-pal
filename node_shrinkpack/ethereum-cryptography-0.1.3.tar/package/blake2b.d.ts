/// <reference types="node" />
export declare function blake2b(input: Buffer, outputLength?: number): Buffer;
//# sourceMappingURL=blake2b.d.ts.map