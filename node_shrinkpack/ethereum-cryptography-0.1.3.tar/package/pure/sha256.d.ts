/// <reference types="node" />
export declare const sha256: (msg: Buffer) => Buffer;
//# sourceMappingURL=sha256.d.ts.map