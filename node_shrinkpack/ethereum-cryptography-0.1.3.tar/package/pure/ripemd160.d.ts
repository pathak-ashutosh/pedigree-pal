/// <reference types="node" />
export declare const ripemd160: (msg: Buffer) => Buffer;
//# sourceMappingURL=ripemd160.d.ts.map