export declare const crypto: {
    node?: any;
    web?: any;
};
