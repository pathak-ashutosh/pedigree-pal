"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.crypto = void 0;
const nodeCrypto = require("crypto");
exports.crypto = {
    node: nodeCrypto,
    web: undefined,
};
//# sourceMappingURL=crypto.js.map