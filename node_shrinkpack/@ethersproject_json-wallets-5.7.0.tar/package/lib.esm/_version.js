export const version = "json-wallets/5.7.0";
//# sourceMappingURL=_version.js.map