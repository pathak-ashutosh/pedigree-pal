export declare function zeroHash(depth: number): Uint8Array;
//# sourceMappingURL=zeros.d.ts.map