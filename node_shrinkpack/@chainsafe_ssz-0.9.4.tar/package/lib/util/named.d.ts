export declare function namedClass<T>(superClass: T, className: string): T;
//# sourceMappingURL=named.d.ts.map