export {};
//# sourceMappingURL=web.d.ts.map