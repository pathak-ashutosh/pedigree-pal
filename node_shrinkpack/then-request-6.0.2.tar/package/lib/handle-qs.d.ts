export default function handleQs(url: string, query: {
    [key: string]: any;
}): string;
