'use strict';

module.exports = require('./lib/detect-port');
module.exports.waitPort = require('./lib/wait-port');
