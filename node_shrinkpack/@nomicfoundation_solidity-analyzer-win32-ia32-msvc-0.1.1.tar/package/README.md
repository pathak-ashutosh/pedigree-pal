# `@nomicfoundation/solidity-analyzer-win32-ia32-msvc`

This is the **i686-pc-windows-msvc** binary for `@nomicfoundation/solidity-analyzer`
