export declare const blake2b: (msg: Uint8Array, outputLength?: number) => Uint8Array;
