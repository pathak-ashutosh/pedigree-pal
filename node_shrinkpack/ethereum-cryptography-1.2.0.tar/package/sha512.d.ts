export declare const sha512: (msg: Uint8Array) => Uint8Array;
