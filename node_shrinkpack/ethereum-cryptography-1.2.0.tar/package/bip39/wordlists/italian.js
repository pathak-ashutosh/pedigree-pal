"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.wordlist = void 0;
var italian_1 = require("@scure/bip39/wordlists/italian");
Object.defineProperty(exports, "wordlist", { enumerable: true, get: function () { return italian_1.wordlist; } });
