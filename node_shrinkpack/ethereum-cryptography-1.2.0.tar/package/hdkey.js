"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HDKey = exports.HARDENED_OFFSET = void 0;
var bip32_1 = require("@scure/bip32");
Object.defineProperty(exports, "HARDENED_OFFSET", { enumerable: true, get: function () { return bip32_1.HARDENED_OFFSET; } });
Object.defineProperty(exports, "HDKey", { enumerable: true, get: function () { return bip32_1.HDKey; } });
