export { HARDENED_OFFSET, HDKey } from "@scure/bip32";
