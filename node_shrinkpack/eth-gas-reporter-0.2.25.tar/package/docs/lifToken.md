### windingtree/LifToken

at commit [1b900a8](https://github.com/windingtree/LifToken/tree/1b900a8c24b18e6c284ca783311f75ece227b79b)

![screen shot 2017-10-22 at 5 39 25 pm](https://user-images.githubusercontent.com/7332026/31868192-2a580c30-b750-11e7-87b6-20508216e33d.png)
