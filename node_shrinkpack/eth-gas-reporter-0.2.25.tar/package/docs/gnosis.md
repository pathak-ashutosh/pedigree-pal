### gnosis/gnosis-contracts

at commit [c81cb17](https://github.com/gnosis/gnosis-contracts/tree/c81cb1736556c88a5cb6a7d9d2b3e2046705675b)


![screen shot 2017-10-22 at 6 19 35 pm](https://user-images.githubusercontent.com/7332026/31868872-83122218-b758-11e7-8162-2814e8b384e1.png)