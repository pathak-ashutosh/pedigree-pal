export declare const wasmCode: Uint8Array;
//# sourceMappingURL=wasmCode.d.ts.map